package playlist.com;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

public class showdata extends HttpServlet{

	protected void processRequest(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.setContentType("text/html");
		try {
			
				Connection con = Connectionprovider.getConnection();
				
				String q = "select * from employee_data1";
				
				PreparedStatement pstm = con.prepareStatement(q);
				
				ResultSet rs = pstm.executeQuery();
				
				
				PrintWriter out = resp.getWriter();
				out.println("<html>");
				out.println("  <style>\r\n"
						+ "           \r\n"
						+ "            body{\r\n"
						+ "                text-align: center;\r\n"
						+ "                background-color: pink ;\r\n"
						+ "            }\r\n"
						+ "            table{\r\n"
						+ "                border: 2px solid black;\r\n"
						+ "                margin: 1px auto;\r\n"
						+ "                width: 60%;\r\n"
						+ "                background-color: lavender;\r\n"
						+ "                padding: 20px 10px;\r\n"
						+ "                margin-top: 90px;\r\n"
						+ "                text-align: center;\r\n"
						+ "\r\n"
						+ "            }\r\n"
						+ "            input[type = email],[type=password],[type=submit][type=reset]{\r\n"
						+ "                height: 36px;\r\n"
						+ "                text-align: center;\r\n"
						+ "                padding: 5px;\r\n"
						+ "            }\r\n"
						+ "            h1{\r\n"
						+ "                color: black;\r\n"
						+ "                text-align:center;\r\n"
						+ "            }\r\n"
						+ "            .button{\r\n"
						+ "                background-color: #4CAF50;\r\n"
						+ "                font-size: large;\r\n"
						+ "                \r\n"
						+ "            }\r\n"
						+ "            img{\r\n"
						+ "                border-radius: 20%;\r\n"
						+ "                border: 0%;\r\n"
						+ "            }\r\n"
						+ "\r\n"
						+ "        </style>");
				out.println("<head><title>Data Display</title></head>");
				out.println("<body>");
	
				out.println("<h1>Data from Database</h1>");
	
				out.println("<table border='1'>");
				out.println("<tr>");
				
				out.println("<th>Employee ID</th>");
				out.println("<th>FirstName</th>");
				out.println("<th>LastName</th>");
				out.println("<th>Email</th>");
				out.println("<th>Gender</th>");
				out.println("<th>ProgrammingLang </th>");
				out.println("<th>DOB</th>");
				out.println("<th>PhoneNumber</th>");
				out.println("<th>Password</th>");
				
			
				out.println("</tr>");
				
				while(rs.next()) {
					int id = rs.getInt(1);
					String fname = rs.getString(2);
					String lname = rs.getString(3);
					String Email = rs.getString(4);
					String Gender = rs.getString(5);
					String ProgrammingLang = rs.getString(6);
					String DOB = rs.getString(7);
					String PhoneNumber = rs.getString(8);
					String Password = rs.getString(9);
					
					  out.println("<tr>");
					    out.println("<td>" + id + "</td>");
					    out.println("<td>" + fname + "</td>");
					    out.println("<td>" + lname + "</td>");
					    out.println("<td>" + Email + "</td>");
					    out.println("<td>" + Gender + "</td>");
					    out.println("<td>" + ProgrammingLang + "</td>");
					    out.println("<td>" + DOB + "</td>");
					    out.println("<td>" + PhoneNumber + "</td>");
					    out.println("<td>" + Password + "</td>");
					
					    out.println("</tr>");
					}
	
					out.println("</table>");
	
				
					out.println("</body>");
					out.println("</html>");

					rs.close();
					pstm.close();
				
				
			
		} catch (Exception e) {
			
			e.printStackTrace();
	
		} 
		
		
	}
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 processRequest(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 processRequest(req, resp);
	}

}
