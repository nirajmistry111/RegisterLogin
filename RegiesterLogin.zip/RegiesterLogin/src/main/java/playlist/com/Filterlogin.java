package playlist.com;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.http.*;
import javax.servlet.*;

public class Filterlogin implements Filter{

	
	
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		// TODO Auto-generated method stub
		
	}
	

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		// TODO Auto-generated method stub
		
		  response.setContentType("Text/Html");
		  PrintWriter writer = response.getWriter();
		  
		  HttpServletRequest req = (HttpServletRequest)request; 
		  HttpSession session = req.getSession(false);
		  
		  String n = (String) session.getAttribute("username");
		  System.out.println(n);
		  
		  if(n!=null)
		     { 
			    chain.doFilter(request, response);
			 }
		  else {
			  System.out.println(req.getMethod());
			  if (req.getMethod().equalsIgnoreCase("GET")) {
		            writer.println("You need to Login First");
		            writer.println("<p><a href='Login.jsp'>Login</a></p>");
		        } else {
				  writer.println("You need to Login First");
				  writer.println("<p><a href = 'Login.jsp'>Login</a></P>"); 
				  }
				  }
		 
		
		
	}
	

	
	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

}
