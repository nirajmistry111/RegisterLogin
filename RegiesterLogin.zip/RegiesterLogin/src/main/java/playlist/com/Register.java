package playlist.com;

import javax.servlet.http.*;


import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;

import javax.servlet.*;
import javax.servlet.annotation.MultipartConfig;

import java.sql.*;

@MultipartConfig
public class Register extends HttpServlet{
	
	private static Connection con;
	
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		
// TO USE HTML TAG TO ENLARGE TEXT IN OUTPUT 
	
		resp.setContentType("text/html");
		
// CREATING OBJECT OF PRINTWRITER IN WHICH WRITER WILL STORE ALL RESPONSE OF INPUT 
		
		
		PrintWriter writer = resp.getWriter();
		System.out.println("<h1> Welcome to Registeration page  </h1>");
		
//  REQUESTING DATA WHICH WERE ENTER BY CLIENT 
		
		
		String firstname = req.getParameter("firstname");
		String lastname  = req.getParameter("lastname");
		String Email	 = req.getParameter("email");
		String Gender	 = req.getParameter("gender");
		String[] progLangs = req.getParameterValues("proglang");
		String selectedLanguages = String.join(", ", progLangs);
		
        String DOB	  = req.getParameter("dob");
        String phonenumber = req.getParameter("phonenumber");
        String password = req.getParameter("pass");
        
        Part filePart = req.getPart("profileimage");
        
        

        
        String fileName = null;
        
        if(filePart == null   ||  progLangs == null ) {
        	
        writer.println("<h1>Programing language or Image not selected </h1>");
        	RequestDispatcher rd = req.getRequestDispatcher("Register.jsp");
        	rd.include(req,resp);
        }else {
			
			  writer.println("<h1> Welcome to Login page  </h1>");
			 writer.println("<h1> " + firstname +" you can Login Now   </h1> ");
			 
			RequestDispatcher rd = req.getRequestDispatcher("Login.jsp");
        	rd.include(req,resp);
        }
        
        
// Read data to show on output screen      
        
        System.out.println("<h2>  Firstname  =  " + firstname    +   "</h2>");
System.out.println("<h2>  Lastname  =  " + lastname    +   "</h2>");
System.out.println("<h2>  Email  =  " + Email    +   "</h2>");
System.out.println("<h2>  Gender  =  " + Gender    +   "</h2>");

for (String lang : progLangs) {
	System.out.println("<h2>  ProgLang  =  " + lang    +   "</h2>");
}

System.out.println("<h2>  Date of Birth  =  " + DOB    +   "</h2>");
System.out.println("<h2>  phonenumber  =  " + phonenumber    +   "</h2>");

System.out.println("<h2>  Password  =  " + password    +   "</h2>");


if (filePart != null) {
    fileName = filePart.getSubmittedFileName();
    InputStream fileContent = filePart.getInputStream();
    System.out.println(" <h2>Uploaded File Name: " + fileName  + "</h2>");
}







//   JDBC CONNECTION 



try{

	Connection con = Connectionprovider.getConnection();
    
    String q = "insert into employee_data1(Firstname , Lastname ,Email , Gender , ProgLang ,DOB ,phonenumber , Password) values (?, ? ,? ,?,?,?,?,?)";


//  Create PreparedStatement object
     PreparedStatement pstmt = con.prepareStatement(q);

     pstmt.setString(1, firstname);
     pstmt.setString(2, lastname);
     pstmt.setString(3, Email);
     pstmt.setString(4, Gender);
     pstmt.setString(5, selectedLanguages); // This is the problem
     pstmt.setString(6, DOB);
     pstmt.setString(7, phonenumber);
     pstmt.setString(8, password);
    


    pstmt.executeUpdate();


  
	 
    System.out.println("Inserted ...");
    
  

  //  con.close();
    
}catch(Exception e){
    System.out.println(e);
}
}    

		
	
}
