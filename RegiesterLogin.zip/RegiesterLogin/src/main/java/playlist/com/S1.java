package playlist.com;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class S1 extends HttpServlet {
	
	
	protected void processRequest(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.setContentType("text/html");
		// USING TRy with resource if not to use catch block 
		try(PrintWriter writer  = resp.getWriter()){
			writer.println("Hello");
			String num1 = req.getParameter("Num1");
			String num2 = req.getParameter("Num2");
			
			int number1 = Integer.parseInt(num1);
			int number2 = Integer.parseInt(num2);
			
			int total = (number1 + number2) ;
			
			
			// By setting object we are coverting the int to object 
			
			req.setAttribute("t", total);
			
			RequestDispatcher rd = req.getRequestDispatcher("S2");
			rd.forward(req,resp);
		}
		
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 processRequest(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 processRequest(req, resp);
	}

}
